minimax
=======

Programa para criação de árvores e simulação de algoritmos minimax e poda alpha-beta
